# -*- coding: utf-8 -*-

SPORTS_KEYWORDS = [
    "Band Sports", "Combate", "Fox Sports", "SPORTV", "DAZN", "ESPN", "PREMIERE", "COPA"
]

SOCCER_KEYWORDS = [
    "SPORTV", "DAZN", "ESPN Brasil", "PREMIERE", "COPA"
]

MOVIES_SERIES_KEYWORDS = [
    "AMC", "Canal Brasil", "Cinemax", "HBO", "Max", "Megapix", "Paramount", "SPACE", "TCM",
    "Telecine Action", "TC Action", "Telecine Cult", "TC Cult", "Telecine Fun", "TC Fun",
    "Telecine Pipoca", "TC Pipoca", "Telecine Premium", "TC Premium", "Telecine Touch",
    "TC Touch", "TNT", "A&E", "AXN", "FOX", "FX", "SONY", "Studio Universal", "SyFy",
    "Universal Channel", "Universal TV", "Warner"
]

KIDS_KEYWORDS = [
    "Baby TV", "BOOMERANG", "CARTOON NETWORK", "DISCOVERY KIDS", "DISNEY", "GLOOB",
    "NAT GEO KIDS", "NICKELODEON", "NICK JR", "PLAYKIDS", "TOONCAST", "ZOOMOO"
]

DOCS_KEYWORDS = [
    "Discovery", "H2 HD", "H2 SD", "H2 FHD", "History", "Nat Geo Wild", "National Geographic"
]

OPEN_TV_KEYWORDS = [
    "Globo", "RECORD", "RedeTV", "Rede Vida", "SBT", "TV Brasil", "TV Cultura", "TV Diario", "BAND"
]

NEWS_KEYWORDS = [
    "CNN", "NEWS"
]

REALITY_KEYWORDS = [
    "BBB", "Big Brother Brasil", "A Fazenda"
]

ADULT_KEYWORDS = [
    "Adult", "ADULT", "Blue Hustler", "PlayBoy", "Redlight", "Sextreme", "SexyHot", "Venus",
    "AST TV", "ASTTV", "AST.TV", "BRAZZERS", "CANDY", "CENTOXCENTO", "DORCEL", "EROXX",
    "PASSION", "PENTHOUSE", "PINK-O", "PINK O", "PRIVATE", "RUSNOCH", "SCT", "SEXT6SENSO",
    "SHALUN TV", "VIVID RED", "Porn", "XY Plus", "XY Mix", "XY Mad", "XXL", "Desire",
    "Bizarre", "Sexy HOT", "Reality Kings", "Prive TV", "Hustler TV", "Extasy", "Evil Angel",
    "Erox", "DUSK", "Brazzers", "Brasileirinhas", "Pink Erotic", "Passion", "Passie",
    "Meiden Van Holland Hard", "Sext & Senso", "Super One", "Vivid TV", "Hustler HD",
    "Sex Ation", "Hot TV", "Hot HD", "MILF", "ANAL", "PUSSY", "ROCCO", "BABES", "BABIE",
    "XY Max", "TUSHY", "BLACKED", "FAKE TAXI", "XXX", "18", "Porno"
]
