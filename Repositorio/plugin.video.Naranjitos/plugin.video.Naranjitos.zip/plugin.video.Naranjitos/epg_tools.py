# -*- coding: utf-8 -*-
import os
import time
import gzip
import re
import datetime
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_URL = "https://www.tdtchannels.com/epg/TV.xml.gz"
EPG_FILE = os.path.join(PROFILE, "epg.xml.gz")
EPG_CACHE_TIME = 3600 * 4  # 4 hours


_EPG_MEMORY_CACHE = None

def get_epg_data(channel_name):
    """
    Returns (title, description) for the current program on the given channel.
    Returns (None, None) if not found.
    """
    global _EPG_MEMORY_CACHE
    
    if not os.path.exists(PROFILE):
        xbmcvfs.mkdir(PROFILE)
        
    download_epg_if_needed()
    
    if _EPG_MEMORY_CACHE is None:
        try:
            content = get_epg_content()
            if not content:
                return None, None
                
            root = ET.fromstring(content)
            _EPG_MEMORY_CACHE = {}
            
            # Build channel map: normalized_name -> id
            channel_map = {}
            for channel in root.findall('channel'):
                cid = channel.get('id')
                display_name = channel.find('display-name')
                if display_name is not None and display_name.text:
                    dname = display_name.text.lower()
                    channel_map[dname] = cid
            
            # Group programmes by channel
            # We only care about CURRENT and maybe NEXT programs to save memory/time?
            # Or just store all and filter on query.
            # Storing all might use memory (XMLTV can be big).
            # Let's filter for programs active NOW or in near future.
            
            now = datetime.datetime.utcnow()
            
            # Pre-calc normalized map for channel IDs to programs
            # _EPG_MEMORY_CACHE = { 'channel_id': [prog1, prog2] }
            
            programs = {}
            for programme in root.findall("programme"):
                # Optimization: check if programme is outdated
                # But parsing dates for all is slow.
                # Just store by channel ID.
                cid = programme.get('channel')
                if cid not in programs:
                    programs[cid] = []
                programs[cid].append(programme)
            
            _EPG_MEMORY_CACHE = {
                'channels': channel_map,
                'programs': programs
            }
            
        except Exception as e:
            xbmc.log("EPG Parse Error: " + str(e), xbmc.LOGERROR)
            return None, None

    if not _EPG_MEMORY_CACHE:
        return None, None
        
    # 1. Find Channel ID
    channel_id = None
    target_name = channel_name.lower().replace(" hd", "").replace(" sd", "").strip()
    
    # Try exact or fuzzy match in channel_map
    for dname, cid in _EPG_MEMORY_CACHE['channels'].items():
        if dname == target_name:
            channel_id = cid
            break
            
    if not channel_id:
         # Fuzzy
         for dname, cid in _EPG_MEMORY_CACHE['channels'].items():
             if target_name in dname or dname in target_name:
                 # La 1 specific preference
                 if "la 1" in target_name and "la 1" in dname:
                     channel_id = cid
                     break
                     
    if "la 1" in target_name and not channel_id:
        channel_id = "La1.es"

    if not channel_id or channel_id not in _EPG_MEMORY_CACHE['programs']:
        return None, None
        
    # 2. Find Current Info
    now = datetime.datetime.utcnow()
    
    for programme in _EPG_MEMORY_CACHE['programs'][channel_id]:
        try:
            start_str = programme.get('start')
            stop_str = programme.get('stop')
            start = parse_xmltv_date(start_str)
            stop = parse_xmltv_date(stop_str)
            
            if start <= now < stop:
                title = programme.find('title').text
                desc_elem = programme.find('desc')
                desc = desc_elem.text if desc_elem is not None else ""
                return title, desc
        except:
            continue
            
    return None, None

def download_epg_if_needed():
    if os.path.exists(EPG_FILE):
        if time.time() - os.path.getmtime(EPG_FILE) < EPG_CACHE_TIME:
            return
            
    try:
        req = urllib2.Request(EPG_URL)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib2.urlopen(req)
        with open(EPG_FILE, 'wb') as f:
            f.write(response.read())
    except Exception as e:
        xbmc.log("Failed to download EPG: " + str(e), xbmc.LOGERROR)

def get_epg_content():
    if not os.path.exists(EPG_FILE):
        return None
    try:
        with gzip.open(EPG_FILE, 'rb') as f:
            return f.read()
    except:
        return None

def parse_xmltv_date(date_str):
    # Flexible parsing
    # Expected: "20231010120000 +0100"
    try:
        # Remove timezone for UTC comparison (assuming system is handling timezones or we treat everything as UTC)
        # XMLTV starts are usually local or UTC with offset. 
        # Easier to convert everything to UTC aware or naive.
        # Let's parse the offset.
        
        # Python 2 (Kodi 18) didn't have bad support, but datetime.strptime with %z is finicky.
        # Simple manual parse
        dt_part = date_str.split(' ')[0]
        tz_part = date_str.split(' ')[1] if ' ' in date_str else '+0000'
        
        dt = datetime.datetime.strptime(dt_part, "%Y%m%d%H%M%S")
        
        # Adjust for timezone
        # If tz_part is +0100, it means the time is 1 hour ahead of UTC. 
        # So to get UTC, we subtract 1 hour.
        
        sign = 1 if tz_part[0] == '+' else -1
        hours = int(tz_part[1:3])
        minutes = int(tz_part[3:5])
        offset = datetime.timedelta(hours=hours, minutes=minutes)
        
        if sign == 1:
            dt_utc = dt - offset
        else:
            dt_utc = dt + offset
            
        return dt_utc
    except:
        return datetime.datetime.utcnow() # Fallback
