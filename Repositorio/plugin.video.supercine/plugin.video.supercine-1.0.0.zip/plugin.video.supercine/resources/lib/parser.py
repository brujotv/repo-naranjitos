# -*- coding: utf-8 -*-
"""
Descarga y parsea el XML de SuperCine.
Maneja XML con etiquetas malformadas (ej. <thumbnail> en lugar de </thumbnail>).
"""
import re
import sys

if sys.version_info[0] >= 3:
    from urllib.request import urlopen
    from urllib.error import URLError, HTTPError
else:
    from urllib2 import urlopen, URLError, HTTPError

URL_XML = "https://raw.githubusercontent.com/brujotv/supercine/refs/heads/master/full.xml"

# Patrón para quitar códigos de color de Kodi del título
RE_COLOR = re.compile(r'\[COLOR\s+[^\]]+\]([^[]*)\[/COLOR\]|\[COLOR[^\]]+\]', re.IGNORECASE)


def _strip_color(txt):
    if not txt:
        return ""
    # Reemplazar [COLOR xxx]texto[/COLOR] por texto; quitar [COLOR xxx] sueltos
    out = RE_COLOR.sub(r'\1', txt)
    return out.strip()


def _extract_tag(block, tag_name):
    # El XML a veces tiene cierre erróneo (ej. <thumbnail>url<thumbnail>)
    open_tag = "<" + tag_name + ">"
    close_tag = "</" + tag_name + ">"
    wrong_close = "<" + tag_name + ">"
    start = block.find(open_tag)
    if start == -1:
        return ""
    start += len(open_tag)
    # Buscar cierre correcto o erróneo
    end1 = block.find(close_tag, start)
    end2 = block.find(wrong_close, start)
    if end1 == -1 and end2 == -1:
        return ""
    if end1 == -1:
        end = end2
    elif end2 == -1:
        end = end1
    else:
        end = min(end1, end2)
    return block[start:end].strip()


def _is_section_header(title_clean):
    # Separadores tipo " -A- ", " -B- ", etc.
    if not title_clean or len(title_clean) < 3:
        return True
    t = title_clean.strip()
    if re.match(r'^-\s*[A-Z0-9Ñ]\s*-$', t, re.IGNORECASE):
        return True
    if t in ("-0-",):
        return True
    return False


def fetch_and_parse():
    """Descarga el XML y devuelve lista de películas (dict con title, link, thumbnail, fanart, genre, year, info)."""
    try:
        req = urlopen(URL_XML, timeout=15)
        data = req.read()
        if isinstance(data, bytes):
            data = data.decode("utf-8", errors="replace")
    except (URLError, HTTPError, Exception) as e:
        return [], str(e)

    # Partir por <item> ... </item>
    items_raw = re.findall(r'<item>\s*([\s\S]*?)\s*</item>', data, re.IGNORECASE)
    movies = []
    for block in items_raw:
        title_raw = _extract_tag(block, "title")
        title_clean = _strip_color(title_raw)
        if _is_section_header(title_clean):
            continue
        link = _extract_tag(block, "link")
        # Puede haber varios <link>; tomar el primero que sea plugin o magnet
        if not link:
            links = re.findall(r'<link>([^<]+)</link>', block, re.IGNORECASE)
            for L in links:
                L = L.strip()
                if L.startswith("plugin://") or "magnet:" in L:
                    link = L
                    break
            if not link and links:
                link = links[0].strip()
        if not link:
            continue
        thumbnail = _extract_tag(block, "thumbnail")
        fanart = _extract_tag(block, "fanart")
        genre = _extract_tag(block, "genre")
        year = _extract_tag(block, "year")
        info = _extract_tag(block, "info")

        movies.append({
            "title": title_clean,
            "title_raw": title_raw,
            "link": link,
            "thumbnail": thumbnail or "",
            "fanart": fanart or "",
            "genre": genre or "",
            "year": year or "",
            "info": info or "",
        })
    return movies, None


def get_years(movies):
    """Lista de años únicos ordenados (desc)."""
    years = set()
    for m in movies:
        y = (m.get("year") or "").strip()
        if y and y.isdigit():
            years.add(y)
    return sorted(years, reverse=True)


def get_genres(movies):
    """Géneros únicos. En el XML pueden venir varios separados por punto (ej. 'Aventuras. Terror')."""
    genres = set()
    for m in movies:
        g = (m.get("genre") or "").strip()
        for part in re.split(r'[.\t]', g):
            p = part.strip()
            if p:
                genres.add(p)
    return sorted(genres)
