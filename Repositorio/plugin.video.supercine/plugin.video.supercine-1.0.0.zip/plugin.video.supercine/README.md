# SuperCine - Addon de vídeo para Kodi

Addon que muestra el catálogo de películas de [SuperCine](https://github.com/brujotv/supercine) con opciones para ver toda la lista o buscar por año, género o título.

## Requisitos

- **Kodi** 18 (Leia) o superior.
- **Elementum** (plugin para reproducir enlaces magnet/torrent). Sin Elementum los enlaces no se reproducirán.

## Instalación

1. Descarga o clona esta carpeta `plugin.video.supercine` en tu equipo.
2. Copia la carpeta **completa** (incluido `icon.png`) en el directorio de addons de Kodi:
   - **Windows:** `%APPDATA%\Kodi\addons\`
   - **Android:** `/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/`
   - **Linux:** `~/.kodi/addons/`
   - **Mac:** `~/Library/Application Support/Kodi/addons/`
3. Si el icono del addon no aparece, reinicia Kodi por completo. Si sigue sin verse, redimensiona `icon.png` a 256×256 píxeles (Kodi suele mostrar mejor iconos de ese tamaño).
4. Reinicia Kodi o ve a *Complementos* → *Mis complementos* → *Complementos de vídeo* y comprueba que aparece **SuperCine**.
5. Ábrelo desde *Complementos* → *Complementos de vídeo* → SuperCine.

## Uso

- **Ver toda la lista:** muestra todo el catálogo.
- **Buscar por año:** elige un año y verás las películas de ese año.
- **Buscar por género:** elige un género (Acción, Comedia, Terror, etc.) y filtra por él.
- **Buscar por título:** escribe parte del nombre de la película para filtrar.

Al seleccionar una película se intentará reproducir con Elementum (magnet/torrent). Asegúrate de tener Elementum instalado y configurado.

## Fuente de datos

El catálogo se obtiene de:
`https://raw.githubusercontent.com/brujotv/supercine/refs/heads/master/full.xml`

## Licencia

GPL-2.0-or-later
