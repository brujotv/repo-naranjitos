# -*- coding: utf-8 -*-
"""
SuperCine - Addon de vídeo para Kodi.
Menú: Películas recientes | Ver toda la lista | Por año | Por género | Por título.
"""
import os
import sys
import urllib.parse
from datetime import date

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import parser

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = ADDON.getAddonInfo("path")


def _url(mode, **kwargs):
    q = urllib.parse.urlencode(kwargs)
    return "{}?mode={}&{}".format(ADDON_URL, mode, q) if q else "{}?mode={}".format(ADDON_URL, mode)


def _art_thumb_fanart(thumbnail, fanart):
    """Usar icono local si la URL es de filmaffinity (403)."""
    base = os.path.join(BASE_URL, "icon.png")
    if thumbnail and "filmaffinity.com" not in (thumbnail or ""):
        t = thumbnail
    else:
        t = base
    if fanart and "filmaffinity.com" not in (fanart or ""):
        f = fanart
    else:
        f = base
    return t, f


def _li(label, url, is_folder=True, icon=None, info=None, fanart=None):
    list_item = xbmcgui.ListItem(label=label)
    list_item.setProperty("IsPlayable", "false" if is_folder else "true")
    if info:
        list_item.setInfo("video", info)
    if icon:
        list_item.setArt({"thumb": icon, "icon": icon})
    if fanart:
        list_item.setArt({"fanart": fanart})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, is_folder)


def main_menu():
    _li("Películas recientes", _url("recent"), icon=os.path.join(BASE_URL, "icon.png"))
    _li("Ver toda la lista", _url("all"), icon=os.path.join(BASE_URL, "icon.png"))
    _li("Buscar por año", _url("year_list"), icon=os.path.join(BASE_URL, "icon.png"))
    _li("Buscar por género", _url("genre_list"), icon=os.path.join(BASE_URL, "icon.png"))
    _li("Buscar por título", _url("search"), icon=os.path.join(BASE_URL, "icon.png"))
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def _get_movies():
    movies, err = parser.fetch_and_parse()
    if err:
        xbmcgui.Dialog().notification("SuperCine", err, xbmcgui.NOTIFICATION_ERROR)
        return []
    return movies


def list_recent():
    """Películas de los últimos 2 años (año actual + anterior), ordenadas por año descendente."""
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    movies = _get_movies()
    current_year = date.today().year
    recent_years = (str(current_year), str(current_year - 1))
    recent = [m for m in movies if (m.get("year") or "").strip() in recent_years]
    recent.sort(key=lambda m: (m.get("year") or "0"), reverse=True)
    for m in recent:
        info = {"title": m["title"], "year": int(m["year"]) if m["year"].isdigit() else 0, "plot": m["info"], "genre": m["genre"]}
        thumb, fanart = _art_thumb_fanart(m["thumbnail"], m["fanart"])
        play_url = _url("play", url=urllib.parse.quote(m["link"], safe=""))
        _li(m["title"], play_url, is_folder=False, icon=thumb, info=info, fanart=fanart)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_all():
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    movies = _get_movies()
    for m in movies:
        info = {"title": m["title"], "year": int(m["year"]) if m["year"].isdigit() else 0, "plot": m["info"], "genre": m["genre"]}
        thumb, fanart = _art_thumb_fanart(m["thumbnail"], m["fanart"])
        play_url = _url("play", url=urllib.parse.quote(m["link"], safe=""))
        _li(m["title"], play_url, is_folder=False, icon=thumb, info=info, fanart=fanart)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def year_list():
    movies = _get_movies()
    years = parser.get_years(movies)
    for y in years:
        _li("Año %s" % y, _url("year", year=y), icon=os.path.join(BASE_URL, "icon.png"))
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_by_year(year):
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    movies = _get_movies()
    for m in movies:
        if (m.get("year") or "").strip() != year:
            continue
        info = {"title": m["title"], "year": int(year), "plot": m["info"], "genre": m["genre"]}
        thumb, fanart = _art_thumb_fanart(m["thumbnail"], m["fanart"])
        play_url = _url("play", url=urllib.parse.quote(m["link"], safe=""))
        _li(m["title"], play_url, is_folder=False, icon=thumb, info=info, fanart=fanart)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def genre_list():
    movies = _get_movies()
    genres = parser.get_genres(movies)
    for g in genres:
        _li(g, _url("genre", genre=urllib.parse.quote(g, safe="")), icon=os.path.join(BASE_URL, "icon.png"))
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_by_genre(genre):
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    movies = _get_movies()
    genre_dec = urllib.parse.unquote(genre)
    for m in movies:
        g = (m.get("genre") or "")
        if genre_dec not in g:
            continue
        info = {"title": m["title"], "year": int(m["year"]) if m["year"].isdigit() else 0, "plot": m["info"], "genre": m["genre"]}
        thumb, fanart = _art_thumb_fanart(m["thumbnail"], m["fanart"])
        play_url = _url("play", url=urllib.parse.quote(m["link"], safe=""))
        _li(m["title"], play_url, is_folder=False, icon=thumb, info=info, fanart=fanart)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def search_by_title():
    kb = xbmc.Keyboard("", "Buscar por título")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    q = kb.getText().strip()
    if not q:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    movies = _get_movies()
    q = q.lower()
    for m in movies:
        if q not in m["title"].lower():
            continue
        info = {"title": m["title"], "year": int(m["year"]) if m["year"].isdigit() else 0, "plot": m["info"], "genre": m["genre"]}
        thumb, fanart = _art_thumb_fanart(m["thumbnail"], m["fanart"])
        play_url = _url("play", url=urllib.parse.quote(m["link"], safe=""))
        _li(m["title"], play_url, is_folder=False, icon=thumb, info=info, fanart=fanart)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def play(url_encoded):
    url = urllib.parse.unquote(url_encoded)
    if not url:
        return
    # PlayMedia hace que el reproductor de Kodi abra la URL (Elementum); RunPlugin no inicia reproducción.
    if url.startswith("plugin://") or url.startswith("magnet:"):
        xbmc.executebuiltin("PlayMedia(%s)" % url)
    else:
        xbmc.Player().play(url)


def run():
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    mode = (args.get("mode") or ["main"])[0]
    if mode == "main":
        main_menu()
    elif mode == "recent":
        list_recent()
    elif mode == "all":
        list_all()
    elif mode == "year_list":
        year_list()
    elif mode == "year":
        list_by_year((args.get("year") or [""])[0])
    elif mode == "genre_list":
        genre_list()
    elif mode == "genre":
        list_by_genre((args.get("genre") or [""])[0])
    elif mode == "search":
        search_by_title()
    elif mode == "play":
        play((args.get("url") or [""])[0])


if __name__ == "__main__":
    run()
