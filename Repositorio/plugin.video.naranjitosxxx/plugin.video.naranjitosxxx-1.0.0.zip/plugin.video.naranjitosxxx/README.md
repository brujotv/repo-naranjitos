# Naranjitos XXX – Addon de Kodi

Addon de video con **Películas X** y **Videos X**, con filtro por género.

## Contenido

- **Películas**: listado desde [peliculas xxx.xml](https://raw.githubusercontent.com/brujotv/xxx/refs/heads/master/peliculas%20xxx.xml) (por género o todos).
- **Videos**: listado desde [videos xxx.xml](https://raw.githubusercontent.com/brujotv/xxx/refs/heads/master/videos%20xxx.xml) (por género o todos).

## Requisitos

- Kodi 19 (Matrix) o superior (Python 3).
- Opcional: **Elementum** para reproducir enlaces magnet/torrent.

## Instalación

### Windows (recomendado para que el icono se vea bien)

1. **Cierra Kodi** por completo.
2. Ejecuta **`INSTALAR_EN_KODI.bat`** desde dentro de la carpeta del addon. Así se copia todo (incluido icono y fanart) a `%APPDATA%\Kodi\addons\`.
3. Para que el icono no salga en verde: borra la caché de Kodi:
   - Elimina la carpeta: `%APPDATA%\Kodi\userdata\Thumbnails`
   - Elimina el archivo: `%APPDATA%\Kodi\userdata\Database\Textures13.db`
4. Abre Kodi de nuevo.

### Instalación manual

1. Copia la carpeta **completa** `plugin.video.naranjitosxxx` (con la subcarpeta `resources` y los archivos `icon.png`, `resources/icon.png`, `resources/fanart.jpg`) a:
   - **Windows**: `%APPDATA%\Kodi\addons\`
   - **Android**: `/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/`
   - **Linux**: `~/.kodi/addons/`
2. Si el icono sale verde: cierra Kodi, borra `Thumbnails` y `Textures13.db` como arriba, y vuelve a abrir Kodi.

## Uso

1. Vídeos → Complementos → **Naranjitos XXX**.
2. Elige **Películas**, **Videos** o **Buscar**.
3. En Películas/Videos: elige **Todos** o un género.
4. En **Buscar**: escribe texto (título o género); busca en películas y videos a la vez.
5. Pulsa sobre un título para reproducir (con Elementum se abrirá el magnet/torrent).

## Fuentes

- Películas: https://raw.githubusercontent.com/brujotv/xxx/refs/heads/master/peliculas%20xxx.xml  
- Videos: https://raw.githubusercontent.com/brujotv/xxx/refs/heads/master/videos%20xxx.xml  
