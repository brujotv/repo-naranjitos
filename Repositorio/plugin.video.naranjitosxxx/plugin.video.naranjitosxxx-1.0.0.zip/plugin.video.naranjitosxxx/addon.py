# -*- coding: utf-8 -*-
"""
Naranjitos XXX - Addon de Kodi
Solo películas desde listado BrujoTV.
"""
import sys
import re
import ssl
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
BASE = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon') or (BASE + '/icon.png')

URL_PELICULAS = 'https://raw.githubusercontent.com/brujotv/xxx/refs/heads/master/peliculas%20xxx.xml'
URL_VIDEOS = 'https://raw.githubusercontent.com/brujotv/xxx/refs/heads/master/videos%20xxx.xml'


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def get_url(**kwargs):
    return ADDON_URL + '?' + urllib.parse.urlencode(kwargs)


def fetch(url):
    """Descarga el contenido de una URL. Prueba varios métodos (SSL sin verificar, xbmcvfs)."""
    content = None
    # 1) urllib con SSL sin verificar (muchos Kodi/Android fallan con certificados)
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0'})
        with urllib.request.urlopen(req, timeout=60, context=ctx) as resp:
            raw = resp.read()
            content = raw.decode('utf-8', errors='replace') if isinstance(raw, bytes) else raw
    except Exception as e:
        log('fetch (SSL unverified) error: %s' % e, xbmc.LOGERROR)
    # 2) xbmcvfs (en algunos Kodi funciona mejor para HTTP)
    if not content or len(content) < 100:
        try:
            f = xbmcvfs.File(url)
            raw = f.read()
            f.close()
            if raw and len(raw) > 100:
                content = raw.decode('utf-8', errors='replace') if isinstance(raw, bytes) else raw
        except Exception as e:
            log('xbmcvfs error: %s' % e, xbmc.LOGERROR)
    # 3) urllib con SSL por defecto
    if not content or len(content) < 100:
        try:
            ctx2 = ssl.create_default_context()
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0'})
            with urllib.request.urlopen(req, timeout=60, context=ctx2) as resp:
                raw = resp.read()
                content = raw.decode('utf-8', errors='replace') if isinstance(raw, bytes) else raw
        except Exception as e:
            log('fetch (SSL default) error: %s' % e, xbmc.LOGERROR)
    if not content or len(content) < 100:
        try:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Error al cargar. Comprueba conexión a Internet.', xbmcgui.NOTIFICATION_ERROR)
        except Exception:
            pass
        return None
    return content.replace('\r\n', '\n').replace('\r', '\n')


def strip_color(t):
    if not t:
        return ''
    return re.sub(r'\[COLOR[^\]]*\]|\[/COLOR\]', '', t).strip()


def parse_entries_xml(content):
    """Parsea XML con <item><title>, <link>, <thumbnail>, <fanart>, <genre>, <year>."""
    entries = []
    if not content or '<item>' not in content:
        return entries
    try:
        # Envolver en root por si no hay uno único
        wrapped = '<root>' + content + '</root>'
        root = ET.fromstring(wrapped)
    except ET.ParseError:
        # Fallback: extraer <item>...</item> con regex
        for m in re.finditer(r'<item>\s*([\s\S]*?)\s*</item>', content):
            block = m.group(1)
            title = re.search(r'<title>([\s\S]*?)</title>', block)
            link = re.search(r'<link>([\s\S]*?)</link>', block)
            thumb = re.search(r'<thumbnail>([\s\S]*?)</thumbnail>', block)
            fanart = re.search(r'<fanart>([\s\S]*?)</fanart>', block)
            genre = re.search(r'<genre>([\s\S]*?)</genre>', block)
            year = re.search(r'<year>([\s\S]*?)</year>', block)
            t = strip_color((title.group(1) if title else '').strip())
            if not t:
                continue
            entries.append({
                'title': t or 'Sin título',
                'url': (link.group(1) if link else '').strip(),
                'thumb': (thumb.group(1) if thumb else '').strip(),
                'fanart': (fanart.group(1) if fanart else '').strip(),
                'genre': (genre.group(1) if genre else '').strip(),
                'year': (year.group(1) if year else '').strip(),
            })
        return entries
    for item in root.findall('.//item'):
        def text(tag):
            el = item.find(tag)
            return (el.text or '').strip() if el is not None else ''
        t = strip_color(text('title'))
        if not t:
            continue
        entries.append({
            'title': t or 'Sin título',
            'url': text('link'),
            'thumb': text('thumbnail'),
            'fanart': text('fanart'),
            'genre': text('genre'),
            'year': text('year'),
        })
    return entries


def parse_entries(content):
    """Parsea listas: primero XML <item>, luego texto [COLOR red]X[/COLOR]."""
    entries = []
    if not content or not isinstance(content, str):
        return entries
    content = content.strip()
    if '<item>' in content and '<title>' in content:
        entries = parse_entries_xml(content)
        if entries:
            return entries
    parts = re.split(r'\s*\[COLOR\s+red\s*\]\s*X\s*\[/COLOR\]\s*', content, flags=re.IGNORECASE)
    if len(parts) <= 1:
        parts = re.split(r'\[COLOR\s+red\]\s*X\s*\[/COLOR\]', content, flags=re.IGNORECASE)
    if len(parts) <= 1:
        parts = re.split(r'\[COLOR\s+red\]X\[/COLOR\]', content, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        if not part or len(part) < 2:
            continue
        lines = [L.strip() for L in part.split('\n') if L and L.strip()]
        if not lines:
            continue
        title = strip_color(lines[0]).strip()
        if not title:
            continue
        url = thumb = fanart = genre = year = ''
        for i in range(1, len(lines)):
            L = lines[i]
            if L.startswith('plugin://'):
                url = L
            elif L.startswith('http://') or L.startswith('https://'):
                if not thumb:
                    thumb = L
                elif not fanart and L != thumb:
                    fanart = L
            elif re.match(r'^\d{4}$', L):
                year = L
            elif ',' in L and not L.startswith('http'):
                genre = L
        entries.append({
            'title': title or 'Sin título',
            'url': url,
            'thumb': thumb or '',
            'fanart': fanart or thumb or '',
            'genre': genre,
            'year': year
        })
    if not entries and '<item>' in content:
        entries = parse_entries_xml(content)
    if not entries and '[COLOR' in content and 'X' in content:
        entries = parse_entries_fallback(content)
    return entries


def parse_entries_fallback(content):
    """Parser alternativo línea a línea."""
    entries = []
    lines = content.split('\n')
    for i in range(len(lines)):
        L = lines[i]
        if '[COLOR' not in L or 'X' not in L or '[/COLOR]' not in L:
            continue
        title = strip_color(L).strip()
        if not title:
            continue
        url = thumb = fanart = genre = year = ''
        for j in range(i + 1, min(i + 20, len(lines))):
            ln = lines[j].strip()
            if not ln:
                continue
            if ln.startswith('plugin://'):
                url = ln
            elif ln.startswith('http://') or ln.startswith('https://'):
                if not thumb:
                    thumb = ln
                elif not fanart and ln != thumb:
                    fanart = ln
            elif re.match(r'^\d{4}$', ln):
                year = ln
            elif ',' in ln and not ln.startswith('http'):
                genre = ln
        entries.append({'title': title, 'url': url, 'thumb': thumb, 'fanart': fanart or thumb, 'genre': genre, 'year': year})
    return entries


def get_genres(entries):
    genres = set()
    for e in entries:
        if e.get('genre'):
            for g in e['genre'].split(','):
                g = g.strip()
                if g:
                    genres.add(g)
    return sorted(genres)


def list_main():
    """Menú: Películas y Videos desde los XML de BrujoTV."""
    xbmcplugin.setPluginCategory(ADDON_HANDLE, ADDON_NAME)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    # Advertencia contenido solo para adultos
    li = xbmcgui.ListItem(label='[COLOR orange]⚠ CONTENIDO SOLO PARA ADULTOS[/COLOR]')
    li.setInfo('video', {'title': 'Advertencia', 'plot': 'Este complemento contiene material destinado exclusivamente a mayores de edad.'})
    li.setArt({'icon': ICON, 'fanart': ICON})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='advertencia'), li, True)
    li = xbmcgui.ListItem(label='Películas')
    li.setInfo('video', {'title': 'Películas'})
    li.setArt({'icon': ICON, 'fanart': ICON})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='peliculas', list_mode='all'), li, True)
    li = xbmcgui.ListItem(label='Videos')
    li.setInfo('video', {'title': 'Videos'})
    li.setArt({'icon': ICON, 'fanart': ICON})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='videos', list_mode='all'), li, True)
    li = xbmcgui.ListItem(label='[B]Buscar[/B]')
    li.setInfo('video', {'title': 'Buscar'})
    li.setArt({'icon': ICON, 'fanart': ICON})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='buscar'), li, True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_genres(mode):
    url = URL_VIDEOS if mode == 'videos' else URL_PELICULAS
    category = 'Videos' if mode == 'videos' else 'Películas'
    xbmcplugin.setPluginCategory(ADDON_HANDLE, category)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    content = fetch(url)
    if not content:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    entries = parse_entries(content)
    genres = get_genres(entries)
    li = xbmcgui.ListItem(label='[B]Todos[/B]')
    li.setInfo('video', {'title': 'Todos'})
    li.setArt({'icon': ICON, 'fanart': ICON})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode=mode, list_mode='all'), li, True)
    for g in genres:
        li = xbmcgui.ListItem(label=g)
        li.setInfo('video', {'title': g})
        li.setArt({'icon': ICON, 'fanart': ICON})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode=mode, genre=urllib.parse.quote(g)), li, True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_items(mode, genre=None):
    url = URL_VIDEOS if mode == 'videos' else URL_PELICULAS
    category = 'Videos' if mode == 'videos' else 'Películas'
    xbmcplugin.setPluginCategory(ADDON_HANDLE, genre or category)
    xbmcplugin.setContent(ADDON_HANDLE, 'episodes' if mode == 'videos' else 'movies')
    content = fetch(url)
    if not content:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    entries = parse_entries(content)
    if genre:
        g = urllib.parse.unquote(genre)
        entries = [e for e in entries if e.get('genre') and g in e['genre']]
    n = 0
    for e in entries:
        url_play = (e.get('url') or '').strip()
        # Solo omitir si no hay URL o está vacía (sin magnet/btih)
        if not url_play or len(url_play) < 50:
            continue
        if url_play == 'plugin://plugin.video.elementum/play?uri=' or (url_play.endswith('play?uri=') and 'magnet:' not in url_play and 'btih:' not in url_play):
            continue
        li = xbmcgui.ListItem(label=e['title'])
        li.setInfo('video', {
            'title': e['title'],
            'genre': [x.strip() for x in e.get('genre', '').split(',') if x.strip()] if e.get('genre') else [],
            'year': int(e['year']) if e.get('year') and str(e['year']).isdigit() else 0
        })
        li.setArt({'icon': e.get('thumb') or 'DefaultVideo.png', 'thumb': e.get('thumb') or '', 'fanart': e.get('fanart') or ICON})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_play, li, False)
        n += 1
    if n == 0:
        li = xbmcgui.ListItem(label='(No hay entradas con enlace)')
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(), li, False)
    try:
        xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def _fetch_all_entries():
    """Obtiene todas las entradas de películas y videos."""
    all_entries = []
    for url, label in [(URL_PELICULAS, 'Películas'), (URL_VIDEOS, 'Videos')]:
        content = fetch(url)
        if not content:
            continue
        entries = parse_entries(content)
        for e in entries:
            e['_source'] = label
            all_entries.append(e)
    return all_entries


def list_buscar():
    """Pantalla de búsqueda: opción de escribir texto + lista de géneros para elegir."""
    xbmcplugin.setPluginCategory(ADDON_HANDLE, 'Buscar')
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    # Opción para escribir búsqueda
    li = xbmcgui.ListItem(label='[B]Escribir búsqueda...[/B]')
    li.setInfo('video', {'title': 'Escribir búsqueda'})
    li.setArt({'icon': ICON, 'fanart': ICON})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='buscar_input'), li, True)
    # Géneros (de películas y videos)
    all_entries = _fetch_all_entries()
    genres = get_genres(all_entries)
    for g in genres:
        li = xbmcgui.ListItem(label=g)
        li.setInfo('video', {'title': g})
        li.setArt({'icon': ICON, 'fanart': ICON})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='buscar_genre', genre=urllib.parse.quote(g)), li, True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_search_genre(genre):
    """Lista entradas de películas y videos que tienen este género."""
    if not genre:
        list_buscar()
        return
    g = urllib.parse.unquote(genre)
    xbmcplugin.setPluginCategory(ADDON_HANDLE, 'Género: %s' % g)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    all_entries = _fetch_all_entries()
    filtered = [e for e in all_entries if e.get('genre') and g in e['genre']]
    n = 0
    for e in filtered:
        url_play = (e.get('url') or '').strip()
        if not url_play or len(url_play) < 50:
            continue
        if url_play == 'plugin://plugin.video.elementum/play?uri=' or (url_play.endswith('play?uri=') and 'magnet:' not in url_play and 'btih:' not in url_play):
            continue
        label = '[%s] %s' % (e.get('_source', ''), e['title'])
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': e['title'],
            'genre': [x.strip() for x in e.get('genre', '').split(',') if x.strip()] if e.get('genre') else [],
            'year': int(e['year']) if e.get('year') and str(e['year']).isdigit() else 0
        })
        li.setArt({'icon': e.get('thumb') or 'DefaultVideo.png', 'thumb': e.get('thumb') or '', 'fanart': e.get('fanart') or ICON})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_play, li, False)
        n += 1
    if n == 0:
        li = xbmcgui.ListItem(label='(No hay entradas con enlace en este género)')
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='buscar'), li, False)
    try:
        xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_search(query):
    """Busca en películas y videos por título o género. Muestra resultados reproducibles."""
    if not query or not query.strip():
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    query = query.strip().lower()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, 'Buscar: %s' % query)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    all_entries = _fetch_all_entries()
    filtered = []
    for e in all_entries:
        title = (e.get('title') or '').lower()
        genre = (e.get('genre') or '').lower()
        if query in title or query in genre:
            filtered.append(e)
    n = 0
    for e in filtered:
        url_play = (e.get('url') or '').strip()
        if not url_play or len(url_play) < 50:
            continue
        if url_play == 'plugin://plugin.video.elementum/play?uri=' or (url_play.endswith('play?uri=') and 'magnet:' not in url_play and 'btih:' not in url_play):
            continue
        label = '[%s] %s' % (e.get('_source', ''), e['title'])
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title': e['title'],
            'genre': [x.strip() for x in e.get('genre', '').split(',') if x.strip()] if e.get('genre') else [],
            'year': int(e['year']) if e.get('year') and str(e['year']).isdigit() else 0
        })
        li.setArt({'icon': e.get('thumb') or 'DefaultVideo.png', 'thumb': e.get('thumb') or '', 'fanart': e.get('fanart') or ICON})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_play, li, False)
        n += 1
    if n == 0:
        li = xbmcgui.ListItem(label='(No se encontró nada para "%s")' % query)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, get_url(mode='buscar'), li, False)
    try:
        xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def play(url):
    if not url:
        return
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)


def router(paramstring):
    if paramstring and (paramstring.startswith('plugin://') or paramstring.startswith('http')):
        play(paramstring)
        return
    try:
        params = dict(urllib.parse.parse_qsl(paramstring))
    except Exception:
        params = {}
    mode = params.get('mode', '')
    genre = params.get('genre', '')
    list_mode = params.get('list_mode', '')
    search_query = params.get('query', '').strip()
    if not mode:
        list_main()
        return
    if mode == 'advertencia':
        xbmcgui.Dialog().ok(
            'Contenido solo para adultos',
            'Este complemento contiene material destinado exclusivamente a mayores de edad (18+).',
            'El uso es bajo su propia responsabilidad.'
        )
        list_main()
        return
    if mode == 'buscar':
        list_buscar()
        return
    if mode == 'buscar_input':
        if search_query:
            list_search(search_query)
        else:
            kb = xbmcgui.Dialog()
            q = kb.input('Buscar (título o género)', type=xbmcgui.INPUT_ALPHANUM)
            if q and q.strip():
                list_search(q.strip())
            else:
                list_buscar()
        return
    if mode == 'buscar_genre':
        list_search_genre(genre)
        return
    if mode == 'peliculas':
        if genre or list_mode == 'all':
            list_items('peliculas', genre=genre if genre else None)
        else:
            list_genres('peliculas')
        return
    if mode == 'videos':
        if genre or list_mode == 'all':
            list_items('videos', genre=genre if genre else None)
        else:
            list_genres('videos')
        return
    list_main()


if __name__ == '__main__':
    p = sys.argv[2] if len(sys.argv) > 2 else ''
    if p.startswith('?'):
        p = p[1:]
    router(p)
