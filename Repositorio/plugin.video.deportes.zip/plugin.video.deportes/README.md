# Deportes IPFS - Addon de Kodi

Addon de video para Kodi que reproduce la lista de canales deportivos desde IPFS.

## Lista de canales

- **URL**: https://ipfs.io/ipns/k2k4r8oqlcjxsritt5mczkcn4mmvcmymbqw7113fz2flkrerfwfps004/data/listas/lista_kodi.m3u
- Incluye: La Liga, Liga de Campeones, DAZN, Movistar Deportes, Fórmula 1, NBA, UFC, Hypermotion, Futbol Int, TDT, etc.

## Requisitos

- **Kodi** 19.x o superior (Matrix/Leia)
- **script.module.horus** (obligatorio) - Los canales usan URLs `plugin://script.module.horus` para reproducir. Debes instalar este módulo para que la reproducción funcione.
- **AceStream** (obligatorio) - Necesario para la reproducción de los streams.

## Instalación

1. **Renombra** la carpeta actual a `plugin.video.deportes` (Kodi requiere que el nombre coincida con el ID del addon)

2. Copia la carpeta `plugin.video.deportes` a la carpeta de addons de Kodi:
   - **Windows**: `%APPDATA%\Kodi\addons\`
   - **Android**: `/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/`
   - **Linux**: `~/.kodi/addons/`

2. O crea un archivo ZIP con el contenido del addon y instala desde Kodi:
   - Configuración → Addons → Instalar desde archivo ZIP

3. Reinicia Kodi y el addon aparecerá en Vídeo → Addons

## Estructura del addon

```
plugin.video.deportes/
├── addon.xml
├── default.py
├── README.md
└── resources/
    └── lib/
        ├── __init__.py
        └── m3u_parser.py
```

## Uso

1. Abre el addon desde Vídeo → Addons
2. Selecciona un grupo (La Liga, DAZN, Movistar Deportes, etc.)
3. Elige un canal para reproducir

## Notas

- El addon descarga la lista M3U desde IPFS al iniciar
- Para añadir un icono: coloca `icon.png` en la raíz del addon
- Para añadir fanart: coloca `fanart.jpg` en la raíz del addon
