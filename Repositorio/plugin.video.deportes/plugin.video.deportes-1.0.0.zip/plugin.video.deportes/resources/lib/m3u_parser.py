# -*- coding: utf-8 -*-
"""
Parser M3U para la lista de canales deportivos
"""

import re
import xbmcaddon

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError
    from urllib.parse import quote
except ImportError:
    from urllib2 import urlopen, Request, URLError
    from urllib import quote

ADDON = xbmcaddon.Addon()
M3U_URL = 'https://ipfs.io/ipns/k2k4r8oqlcjxsritt5mczkcn4mmvcmymbqw7113fz2flkrerfwfps004/data/listas/lista_kodi.m3u'


class M3UParser:
    """Parser para archivos M3U con grupos y canales"""
    
    def __init__(self):
        self._content = None
        self._channels = []
        self._groups = {}
    
    def _fetch_m3u(self):
        """Descarga el contenido M3U desde IPFS"""
        if self._content is not None:
            return self._content
        
        try:
            req = Request(M3U_URL, headers={'User-Agent': 'Kodi/Deportes-Addon'})
            response = urlopen(req, timeout=15)
            self._content = response.read().decode('utf-8', errors='replace')
            return self._content
        except Exception as e:
            ADDON.setSetting('last_error', str(e))
            self._content = ''
            return ''
    
    def _parse(self):
        """Parsea el contenido M3U"""
        if self._channels:
            return
        
        content = self._fetch_m3u()
        if not content:
            return
        
        lines = content.split('\n')
        group_logos = {}  # group_name -> logo
        
        # Primera pasada: recoger logos de grupos (#EXTGRP)
        for line in lines:
            line = line.strip()
            if '#EXTGRP:' in line or 'group-title=' in line:
                grp_match = re.search(r'group-title="([^"]+)"', line)
                logo_match = re.search(r'group-logo="([^"]+)"', line)
                if grp_match:
                    group_logos[grp_match.group(1)] = logo_match.group(1) if logo_match else ''
        
        # Segunda pasada: parsear canales (#EXTINF)
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            if line.startswith('#EXTINF:'):
                tvg_logo = ''
                tvg_id = ''
                group_title = ''
                channel_name = ''
                
                logo_match = re.search(r'tvg-logo="([^"]*)"', line)
                if logo_match:
                    tvg_logo = logo_match.group(1)
                
                id_match = re.search(r'tvg-id="([^"]*)"', line)
                if id_match:
                    tvg_id = id_match.group(1)
                
                group_match = re.search(r'group-title="([^"]*)"', line)
                if group_match:
                    group_title = group_match.group(1)
                
                name_part = line.split(',', 1)
                if len(name_part) > 1:
                    channel_name = name_part[1].strip()
                
                if i + 1 < len(lines):
                    url = lines[i + 1].strip()
                    if url and not url.startswith('#') and group_title:
                        self._channels.append({
                            'name': channel_name or tvg_id or 'Canal',
                            'url': url,
                            'logo': tvg_logo,
                            'tvg_id': tvg_id,
                            'group': group_title
                        })
                        if group_title not in self._groups:
                            self._groups[group_title] = {
                                'name': group_title,
                                'logo': group_logos.get(group_title, tvg_logo)
                            }
                    i += 1
            i += 1
    
    def get_groups(self):
        """Devuelve la lista de grupos"""
        self._parse()
        groups = []
        seen = set()
        for ch in self._channels:
            g = ch['group']
            if g and g not in seen:
                seen.add(g)
                groups.append(self._groups.get(g, {'name': g, 'logo': ''}))
        return sorted(groups, key=lambda x: x['name'])
    
    def get_channels_by_group(self, group_name):
        """Devuelve los canales de un grupo"""
        self._parse()
        return [ch for ch in self._channels if ch['group'] == group_name]
