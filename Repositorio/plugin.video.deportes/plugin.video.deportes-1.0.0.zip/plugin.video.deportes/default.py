# -*- coding: utf-8 -*-
"""
Deportes IPFS - Addon de Kodi para canales deportivos
Reproduce la lista M3U desde IPFS
"""

import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from urllib.parse import urlencode, parse_qsl

from resources.lib.m3u_parser import M3UParser

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ADDON_PATH = ADDON.getAddonInfo('path')


def get_url(**kwargs):
    return '{}?{}'.format(ADDON_URL, urlencode(kwargs))


def show_requirements_warning():
    """Muestra aviso de requisitos solo la primera vez tras la instalación"""
    if ADDON.getSetting('requirements_shown') != 'true':
        xbmcgui.Dialog().ok(
            'Requisitos',
            'Para reproducir los canales es necesario instalar previamente:\n\n'
            '• script.module.horus (obligatorio)\n'
            '• AceStream (obligatorio)\n\n'
            'Sin estos complementos la reproducción no funcionará.'
        )
        ADDON.setSetting('requirements_shown', 'true')


def list_groups():
    """Lista los grupos de canales disponibles"""
    show_requirements_warning()
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    parser = M3UParser()
    groups = parser.get_groups()
    
    for group in groups:
        list_item = xbmcgui.ListItem(label=group['name'])
        list_item.setArt({'icon': group.get('logo', ''), 'thumb': group.get('logo', '')})
        list_item.setInfo('video', {'title': group['name']})
        url = get_url(action='list_channels', group=group['name'])
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, True)
    
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_channels(group_name):
    """Lista los canales de un grupo"""
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    parser = M3UParser()
    channels = parser.get_channels_by_group(group_name)
    
    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['name'])
        list_item.setArt({
            'icon': channel.get('logo', ''),
            'thumb': channel.get('logo', ''),
            'fanart': ADDON.getAddonInfo('fanart') or ''
        })
        list_item.setInfo('video', {
            'title': channel['name'],
            'mediatype': 'video'
        })
        list_item.setProperty('IsPlayable', 'true')
        url = channel['url']
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, False)
    
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def play_channel(url):
    """Reproduce un canal"""
    list_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = params.get('action', 'list_groups')
    
    if action == 'list_groups':
        list_groups()
    elif action == 'list_channels':
        list_channels(params.get('group', ''))
    elif action == 'play':
        play_channel(params.get('url', ''))


if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
